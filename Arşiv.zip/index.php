<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Cloud Storage Search</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="container" style="padding: 20px;">
		<h1 style="text-align: center; margin-bottom: 30px; font-size: 36px;">Media Arama</h1>
		<?php
		require 'vendor/autoload.php';

		use Google\Cloud\Storage\StorageClient;

		// Instantiates a client
		$storage = new StorageClient([
		    'projectId' => 'video-aa805',
		    'keyFilePath' => 'video-aa805-firebase-adminsdk-vot19-c28acfa053.json',
		]);

		// Get the bucket name
		$bucketName = 'video-aa805.appspot.com';

		// Get the bucket object
		$bucket = $storage->bucket($bucketName);

		// If search form is submitted, retrieve the search query and search for matching objects
		if (isset($_POST['search'])) {
		  // Get the search query
		  $searchQuery = $_POST['search'];

		  // Get the list of objects in the bucket that match the search query
		  $options = ['prefix' => $searchQuery];
		  $objects = $bucket->objects($options);

		  // Start the HTML table for search results
		  echo "<table>\n";
		  echo "<thead><tr><th>Dosya Adı</th><th>Görüntüle</th></tr></thead>\n";
		  echo "<tbody>\n";

		  // Loop through each object in the search results and output file name and download link in a table row
		  foreach ($objects as $object) {
            // Get the file name
            $fileName = $object->name();
      
                  
            // Generate a signed URL for downloading the file
            $url = $object->signedUrl(new \DateTime('tomorrow'));
      
            // Output the file name, upload date, and download link in a table row
            echo "<tr><td>$fileName</td><td><a href='$url' download>Görüntüle</a></td></tr>\n";
        }
      

	  // End the HTML table for search results
	  echo "</tbody></table>\n";
	} else {
	  // If search form is not submitted, show only the search form
	  // HTML Form for Search Bar
	  echo "<form action='' method='post' style='display: flex; align-items: center; justify-content: center;'>\n";
	  echo "<input type='text' id='search' name='search' placeholder='Dosya adı ile arama yapın...' style='padding: 10px; border: 1px solid #ccc; border-radius: 4px; flex: 1; max-width: 500px; margin-right: 20px;'>\n";
	  echo "<button type='submit' style='padding: 10px 20px; background-color: #4CAF50; color: white; border: none; border-radius: 4px;'>Ara</button>\n";
	  echo "</form>\n";
	}
	?>
</div>
</body>
</html>